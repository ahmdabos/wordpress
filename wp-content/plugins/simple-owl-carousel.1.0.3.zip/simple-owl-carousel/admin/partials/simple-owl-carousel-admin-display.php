<?php
/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://presstigers.com
 * @since      1.0.0
 *
 * @package    Simple_Owl_Carousel
 * @subpackage Simple_Owl_Carousel/admin/partials
 * @author     PressTigers <support@presstigers.com>
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->